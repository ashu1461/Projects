#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<errno.h>
#include<signal.h>
#include<limits.h>
#include<sys/wait.h>
struct data{
	char name[1000];
};
struct cheenu{
	int flag;
	char name[1000];
	int pid;
};
typedef struct cheenu aa;
typedef struct data a;
aa pid_command[1024];
a info[1024];
int sleep_flag=0;
int info_counter=0;
int pid_counter=0;
char hostname[1024],*whoami;
int error=1;
// .. OR GOING TO DIRECTORY OR RETURNING TO HOME DIRECTORY !!
//char *list[100];
//int counter=0;
void sig_action(int check){
//	if(check==2||check==20)
//	if(check == SIGINT)
//		printf("Received SIGINT\n");
//	if(check == SIGTSTP)
//		printf("Received SIGTSTP\n");
	error=0;
	return;
}
void sig_child(int num){
	pid_t pid=waitpid(WAIT_ANY,NULL,WNOHANG);
	int i;
	for(i=0;i<pid_counter;i++){
		if(pid_command[i].pid==pid){
			pid_command[i].flag=0;
		}
	}
}
int status;
char primary[1024];
int function2(char* primary){
//	char *buffer1=malloc(sizeof(char)*1024);
	char current[1024];
	getcwd(current,sizeof(current));
//	printf("here %s,%s\n",buffer1,buffer);
	if(strcmp(current,primary)==0){
			printf("<%s@%s :~>",whoami,hostname);
		}
	else if(strcmp(current,primary)<0){
			printf("%s@%s :%s~> ",whoami,hostname,current);
		}
	else{
			int a=strlen(primary);
			int b=strlen(current);
			printf("%s@%s :~",whoami,hostname);
			int i;
			for(i=a;i<b;i++){
				printf("%c",current[i]);
			}
			printf("> ");
//			printf("Move forward!!\n");
		}
}
int function(char *s){
//Function to run a specific command !! 
	char temp[1024];
	strcpy(temp,s);
	pid_command[pid_counter].flag=1;
	strcpy(info[info_counter].name,s);
//	printf("here we are %s\n",s);
	info_counter++;
	char *command[100];
//	printf("here is s %s\n",s);
	char *pch=strtok(s,"'\t'' '");
	int i=0;
	while(pch!=NULL){
		command[i]=pch;
		pch=strtok(NULL,"'\t'' '");
		i++;
	}
	command[i]=NULL;
	i++;
	if(strcmp(command[0],"cd")==0){
	// IF THE COMMAND IS CD THEN CHANGE THE DIRECTORY AND WE WOULD WANT TO CHANGE OUR HELLOWORLD !! 
//		strcpy(flag,command[1]);
		if(command[1]==NULL){
			chdir(primary);	
		}
		else
		chdir(command[1]);
		return  ;
	}
	else{
		pid_t pid;
		pid=fork();
		if(pid==0){
			execvp(command[0],command);

		}
		else{
				strcpy(pid_command[pid_counter].name,temp);
				pid_command[pid_counter].pid=pid;
				pid_counter++;
	//			printf("2.string is = %s\n",temp);
			if(temp[strlen(temp)-1]!='&'){
				signal(SIGCHLD,NULL);
//				if(sleep_flag==0){
//				sleep(1);
//				sleep_flag=1;
//				}
				wait(&status);
				signal(SIGCHLD,sig_child);
				pid_command[pid_counter-1].flag=0;
			}
	//		else
	//		{
	//			printf("string is = %s\n",temp);
	//		}
//			info[info_counter].pid=pid;
		}
	}
	return 0;
}
int function3(int n){
	// We have to print the last n commands of history ! 
	int i;
	printf("%d",info_counter);
	n=info_counter-n;
//	printf("here is the value of n %d",n);
	printf("here is the history of the commands\n");
	int p=1;
	for (i=n;i<info_counter;i++){
		printf("%d. %s\n",p,info[i].name);
		p++;
	}
}
int main(){
	gethostname(hostname,1000);
	whoami=getenv("USER");
	int i;
	int status;
	char input[1024];
	char pp;
/*	FILE *fp;
	fp=popen("whoami","r");
	fscanf(fp,"%s",whoami);
	FILE *fp1;
	fp1=popen("hostname","r");
	fscanf(fp1,"%s",hostname);*/
	pid_t uid;
	uid=getpid();
	getcwd(primary,sizeof(primary));
	printf("<%s@%s :~>",whoami,hostname);
	while(1)
	{
		//	function2(primary);
		signal(SIGINT,sig_action);
		signal(SIGTSTP,sig_action);
		signal(SIGCHLD,sig_child);
		gets(input);
//		printf("strlen %d\n",strlen(input));
		//	printf("\ninput-->%s-%d-\n",input,strlen(input));
		if(strcmp(input,"quit")==0){
			return 0;
		}
		else if(strcmp(input,"pid")==0){
			printf("command name: ./a.out process id: %d\n",uid);
		}
		else if(strcmp(input,"pid all")==0){
			for(i=0;i<pid_counter;i++){
				printf("command name: %s process id %d\n",pid_command[i].name,pid_command[i].pid);
			}
		}
		else if(strcmp(input,"pid current")==0){
			for(i=0;i<pid_counter;i++){
				if(pid_command[i].flag==1)
				printf("command name: %s process id %d\n",pid_command[i].name,pid_command[i].pid);
			}
		}
		else if(strcmp(input,"hist")==0){
			function3(info_counter);
		}
		else if(input[0]=='h'&&input[1]=='i'&&input[2]=='s'&&input[3]=='t' && strlen(input) == 5){
			function3((int)input[4]-48);
		}
		else if(input[0]=='!'&&input[1]=='h'&&input[2]=='i'&&input[3]=='s'&&input[4]=='t'){
	//		printf("executing function %s\n",info[info_counter-((int)input[5]-48)].name);
			function(info[info_counter-((int)input[5]-48)].name);
		}
		else{
			if(strlen(input)){
			//		if(error==1){
			function(input);
			//	}
			//	error=RRRR
			}
	}
		function2(primary);
	}
	return 0; 
}
