#include <iostream>
#include <GL/glut.h>
#include <stdio.h>
#include<cmath>
#include<cstdlib>
#include<cstring>
using namespace std;
#define DEG2RAD(deg) (deg * PI / 180)


struct projectors{
        float x1,y1,x2,y2; // the two cordinates
	float d; 	   // the distance to the light source
	int no;		   // the number of pixels
        float x3,y3;       // co -ordinates of projector
};


struct blocks{
        int show ; // this perfroms the task of deletion :D
        int no;
        float r,g,b;
        float prev_r,prev_g,prev_b;
        // red green and blue values :D
        float x1,y1,x2,y2,d;
	float m,c;
	int flag;
	// let us say that x1,y1,x2,y2 are the points to satisfy the equation of the block 
	// ----- >> m and c are parameters ! :D !! 	
        // flag == 0 -> it is a block || flag == 1 -> it is a mirror || flag --> 2 it is a projector
	float checkx,checky;
        float theta;
        float circlex,cricley;
        float radius ;
};
float PI;

float tfactor ;
int current;
char s[1024];
int prev;
int light_flag;
int random_flag;
int global_count;
int gaze_flag , gaze_x , gaze_y;
int gaze_mode ;
int b1; // no of blocks
int p1; // no of projectors
int m1; // no of mirrors
float rfactor;
int game_flag;
struct projectors projector[1000];
struct blocks block[1000];
void initRendering();
void handleResize(int w,int h);
void drawScene();
float tempx,tempy;
FILE *pFile ;
void gaze_rotation(int i);
void create_block(int i,float x1,float y1,float x2,float y2);
void findmouseselection(float x1,float x2);
void doreflection(float x1 ,float x2 ,float y1 , float y2,int zz,float m);
void handleMouseclick(int button, int state, int x, int y);
void handleMouseclick1(int x, int y);
void handleKeypress1(unsigned char key, int x, int y);
void handleKeypress2(int key, int x, int y);
void updateblock(int index,int rflag);
void gamemode();
void update(int i);
float w , h;
int fx , fy ;
float rad1,rad2,rad3,rad4;
float x_rand1 ,y_rand1;
float x_rand2 ,y_rand2;
float x_rand3 ,y_rand3;
float x_rand4 ,y_rand4;
void check_game(float x1,float y1,float x2,float y2);
int stipple_var;
int update_counter;
void update_game(int i);
float rgb_r,rgb_b,rgb_g;
void checkupdate(int i){
    int set;
    if(block[i].x1>block[i].x2)
        set = 1 ;
    else
        set = -1;
    block[i].checkx=((block[i].x1+block[i].x2)/2-(set)*block[i].d*sin(block[i].m));
    block[i].checky=((block[i].y1+block[i].y2)/2+(set)*block[i].d*cos(block[i].m));

}
void insert(int flag){

    if(flag == 1 ){
        // insert mirror
        block[global_count].x1=-w/8;
        block[global_count].x2=+w/8;
        block[global_count].y1=block[global_count].y2=0.0;
        block[global_count].flag=1;
        updateblock(global_count,0);
       // block[global_count].theta=0.0;
        block[global_count].r=block[global_count].prev_r= 1.0f;
        block[global_count].g=block[global_count].prev_g=0.0f;
        block[global_count].b=block[global_count].prev_b=0.0f;
       // block[global_count].checkx=(block[i].x1+block[i].x2)/4;
        //block[global_count].checky=(block[i].y1+block[i].y2)/4;
        block[global_count].show=1;
        if(game_flag==1)
            block[global_count].show=6;
        prev=current;
       // block[prev].r=block[prev].g=block[prev].b=1.0f;
        block[prev].r=block[prev].prev_r;
        block[prev].g=block[prev].prev_g;
        block[prev].b=block[prev].prev_b;
        current = global_count ;
        block[current].r=1.0f,block[current].g=0.0f,block[current].b=1.0f;
        global_count++;


    }
    else if(flag == 2 )
    {
   //     printf("creating a mirror\n");
        // insert block
        block[global_count].x1=-w/8;
        block[global_count].x2=+w/8;
        block[global_count].y1=block[global_count].y2=0.0;

        updateblock(global_count,0);
        block[global_count].r=block[global_count].prev_r= 1.0f;
        block[global_count].g=block[global_count].prev_g=1.0f;
        block[global_count].b=block[global_count].prev_b=1.0f;
        block[global_count].flag=0;
        block[global_count].show=1;
        if(game_flag==1)
            block[global_count].show=6;
        prev=current;
       // block[prev].r=block[prev].g=block[prev].b=1.0f;
        block[prev].r=block[prev].prev_r;
        block[prev].g=block[prev].prev_g;
        block[prev].b=block[prev].prev_b;
        current = global_count ;
        block[current].r=1.0f,block[current].g=0.0f,block[current].b=1.0f;
        global_count++;
    }
    else if((flag==3&&game_flag!=1)){
        // insert projector
        block[global_count].x1=-w/8;
        block[global_count].x2=+w/8;
        block[global_count].y1=block[global_count].y2=0.0;
        block[global_count].d=30.0;
        block[global_count].no=15;

        block[global_count].flag=2;
        block[global_count].r=block[global_count].prev_r= 0.0f;
        block[global_count].g=block[global_count].prev_g=1.0f;
        block[global_count].b=block[global_count].prev_b=0.0f;
        block[global_count].show=1;
        updateblock(global_count,0);
        checkupdate(global_count);
        prev=current;
       // block[prev].r=block[prev].g=block[prev].b=1.0f;
        block[prev].r=block[prev].prev_r;
        block[prev].g=block[prev].prev_g;
        block[prev].b=block[prev].prev_b;
        current = global_count ;
        block[current].r=1.0f,block[current].g=0.0f,block[current].b=1.0f;
        global_count++;

    }
    else if(flag==4){
        // insert projector
        block[global_count].x1=-w/16;
        block[global_count].x2=+w/16;
        block[global_count].y1=block[global_count].y2=0.0;
        block[global_count].d=20.0;
        block[global_count].no=5;

        block[global_count].flag=2;
        block[global_count].r=block[global_count].prev_r= 0.0f;
        block[global_count].g=block[global_count].prev_g=1.0f;
        block[global_count].b=block[global_count].prev_b=0.0f;
        block[global_count].show=6;
        if(game_flag==1)
        block[global_count].show=6;
        updateblock(global_count,0);
        checkupdate(global_count);
        prev=current;
       // block[prev].r=block[prev].g=block[prev].b=1.0f;
        block[prev].r=block[prev].prev_r;
        block[prev].g=block[prev].prev_g;
        block[prev].b=block[prev].prev_b;
        current = global_count ;
        block[current].r=1.0f,block[current].g=0.0f,block[current].b=1.0f;
        global_count++;
    }

}

int findside(float x1,float y1,float x2,float y2,float m,float c){
	if((y1-m*x1-c)*(y2-m*x2-c)>0)
		return 1;
	else 
		return -1;
}
float findm(float x1,float y1,float x2,float y2){
	return atan((y2-y1)/(x2-x1));

}

float findc(float x1,float y1,float x2,float y2){

	return (y1*x2-x1*y2)/(x2-x1);
}
void drawBall(float rad) {
 //   printf("here");
   glBegin(GL_TRIANGLE_FAN);
   for(int i=0 ; i<360 ; i++) {
       glVertex2f(rad * cos(DEG2RAD(i)), rad * sin(DEG2RAD(i)));
   }
   glEnd();
}
void create_game(){

    create_block(global_count,0,h/2,0,h/8);
    block[global_count].show=6;
    global_count++;
    create_block(global_count,0,-h/2,0,-h/8);
    block[global_count].show=6;
    global_count++;
    create_block(global_count,w/2,0,w/8,0);
    block[global_count].show=6;
    global_count++;
    create_block(global_count,-w/2,0,-w/8,0);
    block[global_count].show=6;
    global_count++;
}

void gamemode(){

    //rand()%(max-min)+min;

    //printf("coorindates x y %f %f\n",x_rand,y_rand);
    glPushMatrix();
    glColor3f(0,0,1);
    glTranslatef(x_rand1,y_rand1,0);
    if(rad1>5)
    drawBall(rad1);
    //glTranslatef(-x,-y,0);
    glPopMatrix();
    glPushMatrix();
    glColor3f(0,0,1);
    glTranslatef(x_rand2,y_rand2,0);
    if(rad2>5)
    drawBall(rad2);
    //glTranslatef(-x,-y,0);
    glPopMatrix();
    glPushMatrix();
    glColor3f(0,0,1);
    glTranslatef(x_rand3,y_rand3,0);
    if(rad3>5)
    drawBall(rad3);
    //glTranslatef(-x,-y,0);
    glPopMatrix();
    glPushMatrix();
    glColor3f(0,0,1);

    glTranslatef(x_rand4,y_rand4,0);
    if(rad4>5)
    drawBall(rad4);
    //glTranslatef(-x,-y,0);
    glPopMatrix();
  //  insert(4);
}

float findi(float m1,float c1,float m2,float c2){
   //     printf("finding intersections for %f %f %f %f\n",m1,c1,m2,c2);
	if(m1==m2)
		return 0.0;
	// else find the solution of y = m1x + c1 and y = m2x + c2 --- (m1-m2)x=c2-c1

	tempx = (c2-c1)/(m1-m2);
	tempy = (m1*c2-m2*c1)/(m1-m2);
        return 1.0;
    /*    if((tempx<w/2)&&(tempx>-w/2)&&(tempy>-h/2)&&(tempy<h/2))
            return 1.0;
        else
        return 0.0;*/
}
void createline(float x1,float y1,float x2,float y2,float r,float g,float b){
    /*
//        if(x1< -(w/2+1)||x2 < -(w/2+1)){
//            printf("qwert1234\n");
//            x1 = -w/2+2;
//            x2 = -w/2+2;
//        }
//        if(x1>(w/2-1)||x2>(w/2-1)){
//            printf("qwert1234\n");
//            x1 = w/2-2;
//            x2 = w/2-2;
//        }
//        if(y1<-(h/2+1)||y2<-(h/2+1)){
//            printf("qwert1234\n");
//            y1 = -h/2+2;
//            y2 = -h/2+2;
//        }
//        if(y1>(h/2-1)||y2>(h/2-1)){
//            printf("qwert1234\n");
//            y1 = h/2-2;
//            y2 = h/2-2;
//        }*/
 //   printf("sending lines with rgb %f %f %f\n",r,g,b);

        glPushMatrix();
        glLineWidth (3.0);
        glColor3f(rgb_r,rgb_g,rgb_b);
	glBegin(GL_LINES);
	glVertex2f(x1,y1);
	glVertex2f(x2,y2);
	glEnd();
        glPopMatrix();

}
void createline_stipple(float x1,float y1,float x2,float y2,float r,float g,float b){
    glPushMatrix();
    if(stipple_var==8)
        stipple_var=0;
    glEnable( GL_LINE_STIPPLE );
    glLineStipple(1,0x00ff << stipple_var);
    //glLineStipple( 3, 0x00ff << stipple_var );
   // glLineStipple( 3, 0x00ff);

    glColor3f(rgb_r,rgb_g,rgb_b);
    glBegin(GL_LINES);
    glVertex2f(x1,y1);
    glVertex2f(x2,y2);
    glEnd();
    glDisable( GL_LINE_STIPPLE );
    glPopMatrix();

}

float findroot(float x1,float y1,float x2,float y2){
    return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}
/*void update(int value){
        fx ++ ;
        fy ++ ;

        glutTimerFunc(1000, update, 0);
}
*/
float findmiddle(float x1 , float y1,float x2 , float y2,float x3 , float y3){
    x1 = ((int)x1*1000)/1000.00;
    x2 = ((int)x2*1000)/1000.00;
    x3 = ((int)x3*1000)/1000.00;
    y1 = ((int)y1*1000)/1000.00;
    y2 = ((int)y2*1000)/1000.00;
    y3 = ((int)y3*1000)/1000.00;
    // printf("checking the midle %f %f %f %f %f %f\n",x1,y1,x2,y2,x3,y3);
    //    if(((int)x1==(int)x3&&(int)y1==(int)y3)||((int)x2==(int)x3&&(int)y2==(int)y3))
    //                return 1;
    if((x1==x3&&y1==y3)||(x2==x3&&y2==y3))
        return 1;
    // checking if x3,y3 lie in between x1,y1 and x2,y2 >> ":D"
    if(x2==x3){
        //		printf("here in x same \n");
        if((y1-y3)/(y3-y2)>0)
            return 1;
        else
            return -1;
    }
    else{
        //		printf("here in y same \n");
        if((x1-x3)/(x3-x2)>0)
            return 1;
        else
            return -1;
    }

    // check if x3,y3 lies int he middle of the line segment x1,y1 --- x2,y2 or not :D
}

void findintersection(float x1,float y1,float x2,float y2,int zz,float xi,float yi){
        // This is the function to find the intersection of that line with a mirror or anything .. !
	float m = tan(findm(x1,y1,x2,y2));
	float c = y2-m*x2;
//	printf("here is the slope and the c  %f %f\n",m,c);
	float dist =1000000.0;
	float temp=0.0;
	int k;
        float xdest=block[p1].x1,ydest=block[p1].x2;
  //      printf("-----> all the variables and the slope %f %f %f %f %d %f %f and the slope and c %f %f\n",x1,y1,x2,y2,zz,xi,yi,m,c);
        int info = -1;
        for(k=p1;k<(global_count);k++){
        if(((game_flag==0)&&(k!=zz)&&(block[k].flag!=2)&&(block[k].show==1||block[k].show==2))||((game_flag==1)&&(k!=zz)&&(block[k].flag!=2)&&(block[k].show==2||block[k].show==6))){
   //     printf("here we are ith element %d ===>   %f %f %f %f %d\n and the slope and c %f %f\n",k,block[k].x1,block[k].y1,block[k].x2,block[k].y2,b1+p1,block[k].m,block[k].c);
//	if(block[k].flag==1)
	//	printf("we are facing a mirror \n");
        if(findi(m,c,block[k].m,block[k].c)!=0.0)
        {
//            printf("They intersect :D !! at %f %f\n",tempx,tempy);
            if((tempx < -w/2.00 + 2.00 )&& (tempx > -w/2.00))
                                 tempx = -w/2.00;
                             else if((tempx > w/2.00 - 2.00) && (tempx < w/2.00))
                                 tempx = w/2.00;
                             if((tempy < -h/2.00 + 2.00) && (tempy > -h/2.00))
                                 tempy = -h/2.00;
                             else if((tempy > h/2.0 - 2.00) && (tempy < h/2.00))
                                 tempy = h/2.00;
     //           printf("They redifff !! at %f %f\n",tempx,tempy);
               // if(tempx<w/2&&tempx>-w/2&&tempy>-h/2&&tempy<h/2)
                if((findmiddle(x1,y1,tempx,tempy,x2,y2)==1)){
     //                   printf("<--- cleared the first --->\n");
			if(findmiddle(block[k].x1,block[k].y1,block[k].x2,block[k].y2,tempx,tempy)==1){
             //   printf("They intersect inside :D \n");
		temp=findroot(tempx,tempy,x2,y2);
       //         printf(" comparison b//w dist and temp %f %f\n",temp,dist);
		if(temp<dist){
			info = k ;
//			printf("here inside \n");
			dist=temp;
			xdest=tempx;
			ydest=tempy;
		}
		}
                }
	}
	}
	}
//        printf("----- finally creating line b//w %f %f %f %f\n",xi,yi,xdest,ydest);

        if(info!=-1){
            if(game_flag==1){
            check_game(xi,yi,xdest,ydest);
            }
        if(light_flag!=0){
      //      if(game_flag==1&&block[info].flag==2&&block[info].show==6){
                //printf("passing thru %d %f %f %f %f\n",j,x5,y5,block[i].checkx,block[i].checky);

             createline_stipple(xi,yi,xdest,ydest,rgb_r,rgb_g,rgb_b);
/*//            printf("intially ray going from  %f %f %f %f\n",xi,yi,xdest,ydest);
//            float r = findroot(xi,yi,xdest,ydest);
//            int no = r/50.0;
//            printf("distance and the number and update counter %f %d %d\n",r,no,update_counter);
//            float a1,a2,b1,b2;
//           // light_ray[light_count]
//            if(update_counter<no){
//                a1=(update_counter*xdest+(no-update_counter)*xi)/no;
//                b1=(update_counter*ydest+(no-update_counter)*yi)/no;
//                a2=((update_counter+1)*xdest+(no-update_counter-1)*xi)/no;
//                b2=((update_counter+1)*ydest+(no-update_counter-1)*yi)/no;
//          //              printf("----- finally creating line b//w %f %f %f %f\n",a1,b1,a2,b2);
//               createline(a1,b1,a2,b2,rgb_r,rgb_g,rgb_b);

//            }
//            if(update_counter==no){
//                  p_flag=1;

//            }*/
         // --- > get here
        }
        else{

        createline(xi,yi,xdest,ydest,rgb_r,rgb_g,rgb_b);
        }

        if(block[info].flag==1){
		// check whether they lie on the same side of the plane or not ! :D
//		if(findside(xi,yi,block[info].checkx,block[info].checky,block[info].m,block[info].c)==1)

//                if((xdest-xi)*(block[info].x2-xdest)-(ydest-yi)*(block[info].y2-ydest)>0)
            if((xdest-xi)*(block[info].y2-ydest)-(ydest-yi)*(block[info].x2-xdest)>0)
		doreflection((x2+xdest)/2,(y2+ydest)/2,xdest,ydest,info,block[info].m);
        }
        }
	// after we have the values let us find the point of intersection :D :D !! 
	// check  whether the points have between x2,y2 is between x1,y1 and tempx,tempy
}

void createcircle (int k, int r, int h) {
//	glColor3f(1.0f,0.0f,1.0f);
	float x,y;
	glBegin(GL_LINES);
	for (int i = 0; i < 180; i++)
	{
		x = r * cos(i) - h;
		y = r * sin(i) + k;
		glVertex3f(x + k,y - h,0);

		x = r * cos(i + 0.1) - h;
		y = r * sin(i + 0.1) + k;
		glVertex3f(x + k,y - h,0);
	}
	glEnd();
}

void drawblocks(){
	int i;
 //       printf("here global count %d\n",global_count);
        for(i=0;i<global_count;i++){
       //         printf("%d %d\n",game_flag,block[i].show);
                if((game_flag==0&&block[i].show==1)||(game_flag==1&&block[i].show==6)){
                glPushMatrix();
                glLineWidth (3.0);
                glColor3f(block[i].r,block[i].g,block[i].b);
             //   glRotatef(block[i].theta,0.0f,0.0f,1.0f);
                glBegin(GL_LINES);

		glVertex2f(block[i].x1,block[i].y1);
		glVertex2f(block[i].x2,block[i].y2);
		glEnd();
                glPopMatrix();
                }
//		createline(block[i].x1,block[i].y1,block[i].x2,block[i].y2);
	}
}

void check_game(float x1,float y1,float x2,float y2){
    // check here whether they intersect or not :D
    // find distance from x_rand1 , x_rand2
    float m = tan(findm(x1,y1,x2,y2));
    float c = y2-m*x2;
    float dist1 = fabs((y_rand1-m*x_rand1-c)/(sqrt(1+m*m)));
    float dist2 = fabs((y_rand2-m*x_rand2-c)/(sqrt(1+m*m)));
    float dist3 = fabs((y_rand3-m*x_rand3-c)/(sqrt(1+m*m)));
    float dist4 = fabs((y_rand4-m*x_rand4-c)/(sqrt(1+m*m)));
    //printf("xradn1 yradn1 m c %f %f %f  %f %f %f\n",x_rand1,y_rand1,m,c,rad1,dist);
    if(dist1<rad1){
        rad1=rad1-0.1;
    }
    if(dist2<rad2){
        rad2=rad2-0.1;
    }
    if(dist3<rad3){
        rad3=rad3-0.1;
    }
    if(dist4<rad4){
        rad4=rad4-0.1;
    }
}
/*void drawprojector(){
	int i,j;
	float x3,y3,x4,y4,sq,x5,y5;
//	glRectf(-300.0,60.0,300.0,-60.0);
	for(i=0;i<p1;i++){

                printf("here for i %d\n",i);
		x4=projector[i].x2-projector[i].x1;
		y4=projector[i].y2-projector[i].y1;
		sq=sqrt((x4*x4)+y4*y4);
		x3=projector[i].x2+2*projector[i].d*(y4/sq);
		y3=projector[i].y2-2*projector[i].d*(x4/sq);
//		x3=projector[i].x2+2*projector[i].d*(sqrt((projector[i].y2-projector[i].y1)(projector[i].y2-projector[i].y1)+(projector[i].x2-projector[i].x1)(projector[i].x2-projector[i].x1)))
//		printf("here are the coordinates %f %f \n",x3,y3);
cd
                glColor3f(1.0f,1.0f,1.0f);
		glRectf(projector[i].x1,projector[i].y1,x3,y3);
/// --- >>>

               // findintersection(0.000000 ,0.000000, -6.250000 ,50.000000,-11,0.000000 ,0.000000);

                float div = sq / ((projector[i].no)+1);
               for(j=1;j<projector[i].no+1;j++){

		x5=projector[i].x1+(div*j)*(x4/sq);
                y5=projector[i].y1+(div*j)*(y4/sq);
  //              printf("\n\nolla llaa the points are %d  ",j);
                createline(x5,y5,(projector[i].x1+x3)/2,(projector[i].y1+y3)/2);
                findintersection((projector[i].x1+x3)/2,(projector[i].y1+y3)/2,x5,y5,-11,(projector[i].x1+x3)/2,(projector[i].y1+y3)/2);

                }
		// now we have drawn the projector we need to find its HOLES ! :D ! 
	}
}*/

void linestrip(){
//	glLineWidth(2.0);
	// Enable line stippling
	glEnable(GL_LINE_STIPPLE);
	// Set the stippling pattern
	glLineStipple(3, 0xAAAA);
//	glEnable(GL_LINE_STIPPLE);
//	GLint factor =	10 ;
//	GLushort pattern = 0x5555;
	glBegin(GL_LINE_STIPPLE);
	glVertex3f(0.0f,0.0f,0.0f);
	glVertex3f(10.0f,10.0f,0.0f);
	glVertex3f(15.0f,5.0f,0.0f);
	glEnd();
}


void drawprojector(){
    int i,j,mid;
    rgb_r=0.0,rgb_g=0.0,rgb_b=0.0;
    float x5,y5;
    for(i=0;i<global_count;i++){
        if((game_flag==0&&(block[i].flag==2&&block[i].show==1))||(game_flag==1&&(block[i].flag==2&&block[i].show==6))){
        if(gaze_mode==1){
        //     printf("here %d %d\n",gaze_x,gaze_y);
            gaze_rotation(i);
        }
        //float div = findroot(block[i].x1,block[i].y1,block[i].x2,block[i].y2)/(block[i].no+1);
        for(j=1;j<=block[i].no;j++)
        {
           if(block[i].no%2!=0)
            mid = (block[i].no-1)/2;
           else
            mid = (block[i].no-1)/2 +1;
   //        printf("%d %d %d %d\n",1,block[i].no,mid,mid-1);
           x5=(j*block[i].x2+(block[i].no-j+1)*block[i].x1)/(block[i].no+1);
           y5=(j*block[i].y2+(block[i].no-j+1)*block[i].y1)/(block[i].no+1);
//         printf("\n\nike tune beechare coord for %d %d %f %f\n",i,j,x5,y5);
           if(j>=1&&j<=mid){
               rgb_r = 1.00 - (float)(j-1)/(mid-1);
               rgb_g = 0.00 + (float)(j-1)/(mid-1);
               rgb_b = 0 ;

           }
           if(j>mid&&j<=block[i].no){
               rgb_r=0;
               rgb_g=1.00 - (float)(j-mid-1)/(block[i].no-mid-1);
               rgb_b=1.00 + (float)(j-mid-1)/(block[i].no-mid-1);
           }
    //       printf("sending lines with rgb %f %f %f\n",rgb_r,rgb_g,rgb_b);
           createline(x5,y5,block[i].checkx,block[i].checky,rgb_r,rgb_g,rgb_b);

         //  else
       //        createline(x5)
           if(gaze_flag==0){
           findintersection(block[i].checkx,block[i].checky,x5,y5,-11,x5,y5);
           }
           else
               findintersection(x5,y5,gaze_x,gaze_y,-11,x5,y5);

        }
    }
    }
}
void perform_translation(int i ,int j,int k){

    if((game_flag==1&&block[k].flag!=0)||game_flag==0){
    if((block[k].x1+i*tfactor<w/2)&&(block[k].x1+tfactor*i>-w/2)&&(block[k].x2+i*tfactor<w/2)&&(block[k].x2+tfactor*i>-w/2)){
        //printf("%f %f\n",block[k].y2+j*tfactor,block[k].y1+j*tfactor);
        if((block[k].y1+j*tfactor<h/2)&&(block[k].y1+tfactor*j>-h/2)&&(block[k].y2+j*tfactor<h/2)&&(block[k].y2+j*tfactor>-h/2)) {
            if((block[k].checkx+i*tfactor<w/2)&&(block[k].checkx+i*tfactor>-w/2)&&(block[k].checky+j*tfactor<h/2)&&(block[k].checky+j*tfactor>-h/2)){
    block[k].x1=block[k].x1+i*tfactor;
    //if((block[i].x2+i*tfactor<w/2)&&(block[i].x2+tfactor*i>-w/2))
    block[k].x2=block[k].x2+i*tfactor;


    block[k].y1=block[k].y1+j*tfactor;
    block[k].y2=block[k].y2+j*tfactor;
    updateblock(k,0);
    if(block[k].flag==1||block[k].flag==2){
        block[k].checkx=block[k].checkx+i*tfactor;
         block[k].checky=block[k].checky+j*tfactor;
    }
   }
        }
}
}
}

void perform_rotation(int i,int k){
    float tx1 , ty1 , tx2 , ty2 ;
   // printf("22222");
    tx2 = block[k].x2-block[k].x1;
    ty2 = block[k].y2-block[k].y1;
    tx1 = tx2*cos(i*rfactor*PI/180) - ty2*sin(i*rfactor*PI/180);
    ty1 = tx2*sin(i*rfactor*PI/180) + ty2*cos(i*rfactor*PI/180);
    block[k].x2=block[k].x1+tx1;
    block[k].y2=block[k].y1+ty1;
    if(block[k].flag==1||block[k].flag==2){
    tx2 = block[k].checkx-block[k].x1;
    ty2 = block[k].checky-block[k].y1;
    tx1 = tx2*cos(i*rfactor*PI/180) - ty2*sin(i*rfactor*PI/180);
    ty1 = tx2*sin(i*rfactor*PI/180) + ty2*cos(i*rfactor*PI/180);
    block[k].checkx=block[k].x1+tx1;
    block[k].checky=block[k].y1+ty1;
    }
    updateblock(k,1);
}
void perform_random(){
    srand(time(NULL));

    int random_integer =rand();
    int i=0;
    i = rand()%(p1+m1+b1);
  //  for(i=0;i<p1+m1+b1;i++){
        if(block[i].show==1){
            if(random_integer%4==0){
                  perform_translation(1,0,i);
          /*      if(block[i].x1+)

                if((tempx < -w/2.00 + 2.00 )&& (tempx > -w/2.00))
                    tempx = -w/2.00;
                else if((tempx > w/2.00 - 2.00) && (tempx < w/2.00))
                    tempx = w/2.00;
                if((tempy < -h/2.00 + 2.00) && (tempy > -h/2.00))
                    tempy = -h/2.00;
                else if((tempy > h/2.0 - 2.00) && (tempy < h/2.00))
                    tempy = h/2.00;*/

        }
        else if(random_integer%4==1){
            perform_translation(-1,0,i);
        }
        else if(random_integer%4==2){
            perform_translation(0,-1,i);
        }
        else if(random_integer%4==3){
            perform_translation(0,1,i);
        }
        }
  //  }
    // perform random motion !

//    perform_translation(2,0,i);
//    perform_translation(0,2,i);
//    perform_translation(-2,0,i);
//    perform_translation(0,-2,i);

}
void findline(){
    // to find a line between the files !

    while(fgets(s,sizeof s,pFile)){
   //     printf("%s",s);
       if(strcmp(s,"\n")!=0&&s[0]!='#')
            break;
    }
}
void create_block(int i,float x1,float y1,float x2,float y2){
    // create 4 boundary blocks here ..
    block[i].x1=x1;
    block[i].x2=x2;
    block[i].y1=y1;
    block[i].y2=y2;
    updateblock(i,0);
    block[i].r=block[i].prev_r= 1.0f;
    block[i].g=block[i].prev_g=1.0f;
    block[i].b=block[i].prev_b=1.0f;
    block[i].flag=0;
    block[i].show=2;
}

void write2file(){
    pFile = fopen("Output.txt","w");
    fprintf(pFile,"%f %f\n",w,h);
    fprintf(pFile,"%d\n",p1);
    int i;
    for(i=0;i<p1;i++){
        fprintf(pFile,"%f %f %f %f\n",block[i].x1,block[i].y1,block[i].x2,block[i].y2);
        fprintf(pFile,"%f\n",block[i].d);
        fprintf(pFile,"%d\n",block[i].no);
    }
    fprintf(pFile,"%d\n",b1);
    for(i=p1;i<p1+b1;i++){
        fprintf(pFile,"%f %f %f %f\n",block[i].x1,block[i].y1,block[i].x2,block[i].y2);

    }
    fprintf(pFile,"%d\n",m1);
    for(i=p1+b1;i<p1+b1+m1;i++){
        fprintf(pFile,"%f %f %f %f\n",block[i].x1,block[i].y1,block[i].x2,block[i].y2);

    }
    fclose(pFile);
}

int main(int argc,char**argv){
        game_flag=0;
        pFile = fopen(argv[1],"r");
        update_counter=0.0;
        PI = 3.141592653589;
        stipple_var=0;
        gaze_flag=gaze_mode=0;
        light_flag=0;
//        light_count=0;
        random_flag=0;
        rfactor =5.0;
        p1=0;
        rad1=rad2=rad3=rad4=10.0;
        m1=0;
        fx = 0 , fy =0;
        current=0;
        tfactor=1.2;
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
        findline();
        sscanf(s,"%f %f",&w,&h);
       //// --  printf("------%f %f\n",w,h);

	int i;
        findline();
        sscanf(s,"%d",&p1);
	for(i=0;i<p1;i++){
                findline();
                sscanf(s,"%f %f %f %f",&block[i].x1,&block[i].y1,&block[i].x2,&block[i].y2);
                findline();
                sscanf(s,"%f",&block[i].d);
                findline();
                sscanf(s,"%d",&block[i].no);
                block[i].flag=2;
                block[i].r=block[i].prev_r= 0.0f;
                block[i].g=block[i].prev_g=1.0f;
                block[i].b=block[i].prev_b=0.0f;
                block[i].show=1;
                updateblock(i,0);
                checkupdate(i);

           //     block[i].checkx=((block[i].x1+block[i].x2)/2+block[i].d*sin(block[i].m));
            //    block[i].checky=((block[i].y1+block[i].y2)/2-block[i].d*cos(block[i].m));
//
  //              printf("the cordinates are %f %f\n",block[i].checkx,block[i].checky);
            //   glPushMatrix();
         //       glColor3f(1.0f,1.0f,0.0f);

              // createline(0.0,0.0,block[i].checkx,block[i].checky);
          //     glPopMatrix();

	}

//	printf("%f\n",findi(1.0,2.0,1.00,3.0));
        findline();
        sscanf(s,"%d",&b1);

//	printf("then value of b1 is --- %d\n",b1);
        for(i=p1;i<b1+p1;i++){
           findline();
           sscanf(s,"%f %f %f %f",&block[i].x1,&block[i].y1,&block[i].x2,&block[i].y2);
           updateblock(i,0);
           block[i].r=block[i].prev_r= 1.0f;
           block[i].g=block[i].prev_g=1.0f;
           block[i].b=block[i].prev_b=1.0f;
           block[i].flag=0;
           block[i].show=1;
//		printf("here we are ==2121=>   %f %f %f %f %f %f\n",block[i].x1,block[i].y1,block[i].x2,block[i].y2,block[i].m,block[i].c);
        }
        findline();
        sscanf(s,"%d",&m1);
        for(i=b1+p1;i<b1+m1+p1;i++){
            findline();
                sscanf(s,"%f %f %f %f",&block[i].x1,&block[i].y1,&block[i].x2,&block[i].y2);
                block[i].flag=1;
                updateblock(i,0);
                block[i].theta=0.0;
                block[i].r=block[i].prev_r= 1.0f;
                block[i].g=block[i].prev_g=0.0f;
                block[i].b=block[i].prev_b=0.0f;
                block[i].checkx=(block[i].x1+block[i].x2)/4;
                block[i].checky=(block[i].y1+block[i].y2)/4;
                block[i].show=1;

        }
        fclose(pFile);
        global_count=b1+m1+p1;
        create_block(global_count,-w/2,-h/2,-w/2,h/2);
        global_count++;
        create_block(global_count,-w/2,-h/2,w/2,-h/2);
        global_count++;
        create_block(global_count,w/2,-h/2,w/2,h/2);
        global_count++;
        create_block(global_count,w/2,h/2,-w/2,h/2);
        global_count++;
        game_flag=1;
        insert(4);
        create_game();
        game_flag=0;

        glutInitWindowPosition(0,0);
	glutInitWindowSize(w,h);
	glutCreateWindow("Dudde");
	initRendering();
	glutReshapeFunc(handleResize);
	glutDisplayFunc(drawScene);
        glutIdleFunc(drawScene);
        glutKeyboardFunc(handleKeypress1);
        glutSpecialFunc(handleKeypress2);
        glutMouseFunc(handleMouseclick);
        glutPassiveMotionFunc(handleMouseclick1);
        glutTimerFunc(10, update, 0);
        glutTimerFunc(1000, update_game, 0);
	glutMainLoop();
	return 0;
}
void update_game(int i){
 //  printf("%f %f %f %f\n",rad1,rad2,rad3,rad4);
    if(game_flag==1){
    if(rad1!=0.0)
    rad1=rad1+0.5;
    if(rad2!=0.0)
    rad2=rad2+0.5;
    if(rad3!=0.0)
    rad3=rad3+0.5;
    if(rad4!=0.0)
    rad4=rad4+0.5;
    if(rad1>30.0||rad2>30.0||rad3>30.0||rad4>30.0){
        game_flag=0;
        printf("You Loose Buhahahaha \n");
        rad1=rad2=rad3=rad4=10.0;
    }

    if(rad1<3.0)
        rad1=0.0;
    if(rad2<3.0)
        rad2=0.0;
    if(rad3<3.0)
        rad3=0.0;
    if(rad4<3.0)
        rad4=0.0;



    else if(rad1<5.0&&rad2<5.0&&rad3<5.0&&rad4<5.0){
        game_flag=0;
        printf("YOu win buhahaha \n");
        rad1=rad2=rad3=rad4=10.0;
    }
    }
      //glLineStipple( 3, 0x00ff << stipple_var++ );
      glutTimerFunc(500, update_game, 0);
}

void update(int i){
    stipple_var = 0x00ff << i;
     if (i > stipple_var)
      stipple_var+= 0x00ff >> (8-(i-8));
      i++;
     glutTimerFunc(10, update, i);
}

void doreflection(float x1,float y1,float xdest,float ydest,int zz,float m){

// ==> this would be performed when the ray y = m2x + c2 is reflected from y = m1x + c2
	
        // find a line which passes through the point x1,y1 and has slope m
	// find a line whih passes through the point xdest,ydest and has slope -1/m

//	printf("slope of the line and the block %f \n",m );
        //printf("In the reflection ");
	float m2 = tan(atan(-1/m));
	float c1 = y1-m*x1;
	float c2 = ydest - xdest*m2;
	findi(m,c1,m2,c2);
		
	// we need to find co-ordinates first !: DD
	// xdest and ydest are the co-ordinates 
	// equation is ydset = m3*xdest + c 
//	printf("dododododo --- > x1,y1,tempx,tempy %f %f %f %f\n",x1,y1,tempx,tempy);
	findintersection(xdest,ydest,2*tempx-x1,2*tempy-y1,zz,xdest,ydest);	
//	createline(x2,y2,xdest,ydest);

}
void handleMouseclick(int button, int state , int x , int y){
   x=x-300;
   y=300-y;
//    printf("good boy nathani --- >>> %d %d\n",x,y);

    if(state == GLUT_DOWN){
        if(button == GLUT_LEFT_BUTTON){
            findmouseselection(x,y);

        }
    }

}
void findmouseselection(float x, float y){
        // find the shortest distance from the m1+p1+b1 elements to the mouse selection !
        //printf("good boy nathani --- >>> %f %f\n",x,y);

        int i;

        float dist = 1000000.00;
        float temp ;
        int info = 0 ;
        for(i=0;i<p1+m1+b1;i++){
            if(block[i].show==1){
   /*         if(fabs(block[i].m)>20000000.000000){
                 temp = block[i].x1-x;
            }
            else*/
            temp = (y-block[i].m*x -block[i].c)/sqrt(1+block[i].m*block[i].m);
      //    printf("data is here %f %f %d\n",block[i].m,block[i].c,i);
       //     printf("%f %f\n",temp,dist);
            if(fabs(temp) < dist){
       //         printf("isnide\n");
                dist = fabs(temp);
            //    block[prev].r=block[prev].g=block[prev].b=1.0f;
             //   block[current].g=1.0f;
                info = i;
            }

        }
        prev = current ;
        current = info;
      //  printf("prev and current %d %d\n",prev , current);
        block[prev].r=block[prev].prev_r;
        block[prev].g=block[prev].prev_g;
        block[prev].b=block[prev].prev_b;
        block[current].r=1.0f,block[current].g=0.0f,block[current].b=1.0f;
        }
}
void gaze_rotation(int i){

//    float slope = tan(atan(-1/block[i].m));
//    float slope2 = tan(atan((gaze_y-block[i].checkx)/(gaze_x-block[i].checky)));
//    float slope3 = fabs((slope-slope2)/(1-slope*slope2));
//    rfactor=1.0;
      //perform_rotation((90.00-90.00),i);

   // printf("%d %d\n",gaze_x,gaze_y);
    // <------------------------
   // float m = tan(findm(gaze_x,gaze_y,block[i].checkx,block[i].checky));
    float l = findroot(block[i].x1,block[i].y1,block[i].x2,block[i].y2);
    float R =findroot(block[i].checkx,block[i].checky,gaze_x,gaze_y);
    float cost = (gaze_x-block[i].checkx)/R;
    float sint = (gaze_y-block[i].checky)/R;
    block[i].x1 = block[i].checkx + block[i].d*cost+(l/2)*sint;
    block[i].y1 = block[i].checky + block[i].d*sint-(l/2)*cost;
    block[i].x2 = block[i].checkx + block[i].d*cost-(l/2)*sint;
    block[i].y2 = block[i].checky + block[i].d*sint+(l/2)*cost;
  //  }

    /*
    float a = (block[i].x1+block[i].x2)/2;
    float b = (block[i].y1+block[i].y2)/2;
    float R = findroot(a,b,gaze_x,gaze_y);
    // x -a /R
    float cost = (gaze_x-a)/R;
    float sint = (gaze_y-b)/R;
    float r = findroot(block[i].x1,block[i].y1,block[i].x2,block[i].y2);
    block[i].x2 = a + (r/2)*sint;
    block[i].x1 = a - (r/2)*sint;
    block[i].y2 = b - (r/2)*cost;
    block[i].y1 = b + (r/2)*cost;
    checkupdate(i);



    float angle,x1,y1,x2,y2,xs,ys,d,mx,my;
    x1=block[i].x1; x2=block[i].x2;
    y1=block[i].y1; y2=block[i].y2;
    xs=block[i].checkx; ys=block[i].checky;
    angle=(atan((gaze_y-ys)/(gaze_x-xs)));
    d=sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
    mx=(x1+x2)/2; my=(y1+y2)/2;
    x1=mx-(d/2*sin(angle)); y1=my+(d/2*cos(angle));
    x2=mx+(d/2*sin(angle)); y2=my-(d/2*cos(angle));
    block[i].x1=x1;  block[i].x2=x2;
    block[i].y1=y1;  block[i].y2=y2;
*/


}

void handleMouseclick1(int x ,int y){
    gaze_x=x-300;
    gaze_y=300-y;
  //  printf("good boy nathani --- >>> %d %d\n",x,y);
}
void handleKeypress1(unsigned char key, int x, int y){
    if(key == 113 || key ==27){
        write2file();
        exit(0);
    }
    if(key == 99){
        prev=current;
        current=(current+1)%global_count;
        if(game_flag==0){
            while(block[current].show!=1){
                current=(current+1)%global_count;
            }
        }
        else
            while(block[current].show!=6){
                current=(current+1)%global_count;
            }
        // change color of prev and current
        block[prev].r=block[prev].prev_r;
        block[prev].g=block[prev].prev_g;
        block[prev].b=block[prev].prev_b;
        block[current].r=1.0f,block[current].g=0.0f,block[current].b=1.0f;
    }
    else if(key == 108){
        // left rotate
                perform_rotation(1,current);


    }
    else if(key == 114){
        // right rotate
        perform_rotation(-1,current);

    }

    else if(key == 102){
        // the f key to make faster translations
        tfactor = tfactor + 1 ;
        rfactor = rfactor + 5 ;
    }
    else if(key == 115 ){
        // s to make slow !!
        if(tfactor > 1)
        tfactor = tfactor -1;
        if(rfactor > 5)
            rfactor = rfactor - 5 ;
    }
    else if(key == 103){

      //  perform_random();
          gaze_mode=!gaze_mode;
          gaze_flag=!gaze_flag;
 //       gaze_mode=!gaze_mode;

        // gaze towards the mouse :D !!
    }
    else if(key == 122){
        random_flag=!random_flag;
    }
    else if(key == 111){
            // perform gaze_,motion by gaze _ mode
            // we have gaze_x , gaze _y
      //  printf("here %d %d",gaze_x,gaze_y);
        gaze_flag=!gaze_flag;
    }
    else if(key == 112){
            insert(3);
    }
    else if(key==98){
        // create a block
        insert(2);
    }
    else if(key==109){
        // create a mirror
        insert(1);
    }
    else if(key==127){
        // create a mirror
  //      printf("deleting an object");
        block[current].show=0;
    }
    else if(key==116){
        // create a mirror
        light_flag=!light_flag;
//        update_counter=0;
    }
    else if(key==80){
        // create a mirror
        game_flag=!game_flag;

        srand(time(NULL));
        x_rand1 = (float)(rand()%(int)(w/2-40))+20.0;
        y_rand1 = (float)(rand()%(int)(h/2-40))+20.0;


        x_rand2 = -((float)(rand()%(int)(w/2-40))+20.0);
        y_rand2 = -((float)(rand()%(int)(h/2-40))+20.0);


        x_rand3 = -(float)(rand()%(int)(w/2-40))+20.0;
        y_rand3 = (float)(rand()%(int)(h/2-40))+20.0;


        x_rand4 = (float)(rand()%(int)(w/2-40))+20.0;
        y_rand4 = -(float)(rand()%(int)(h/2-40))+20.0;



        gamemode();


//        update_counter=0;
    }
}
void handleKeypress2(int key, int x, int y){
  //  printf("mylove\n");
    if(key== GLUT_KEY_LEFT){
        perform_translation(-1,0,current);

    }
    else if(key== GLUT_KEY_RIGHT){
    perform_translation(1,0,current);

    }
    else if(key== GLUT_KEY_UP){
        perform_translation(0,1,current);

    }
    else if(key== GLUT_KEY_DOWN){
        perform_translation(0,-1,current);
}
}


void updateblock(int index,int rflag){
        block[index].m=tan(findm(block[index].x1,block[index].y1,block[index].x2,block[index].y2));
        block[index].c=block[index].y1-block[index].m*block[index].x1;
}



void drawScene(){

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


        //	drawprojector();
//if(game_flag==0){
	drawblocks();
        drawprojector();
//}
        if(game_flag==1){
            gamemode();
        }

        if(random_flag==1)
        perform_random();
//	glTranslatef(0.0f,0.0f,-5.0f);
/*
	glColor3f(0.0f,1.0f,0.0f);
	glRectf(-50.0f,0.f,50.0f,-50.0f);*/
//reatecircle(0,100,0);

/*

// i can fuck a LAMMA NOW BITCH
/*	glBegin(GL_LINES);
		glVertex2i(180,15);
		glVertex2i(10,145);
	glEnd();

	
/*

	glPushMatrix();
		glPushMatrix();



	glEnable(GL_LINE_STIPPLE);
	glColor3f(0.0f,0.0f,1.0f);
	// Set the stippling pattern
	glLineStipple(3, 0xAAAA);
	glBegin(GL_LINE_STIPPLE);
	glVertex3f(60.0f,60.0f,0.0f);
	glVertex3f(60.0f,-60.0f,0.0f);
	glVertex3f(-60.0f,-60.0f,0.0f);
	glVertex3f(-60.0f,60.0f,0.0f);
	glVertex3f(60.0f,60.0f,0.0f);
	glEnd();*/
///		glPopMatrix();
//		glPopMatrix();
	glutSwapBuffers();
}

void initRendering(){
        glClearColor(0.0f,0.0f,0.0f,1.0f);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_COLOR_MATERIAL);
}

void handleResize(int w, int h){
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION); //Switch to setting the camera perspective
	glLoadIdentity(); //Reset the camera
	gluOrtho2D(-w/2,w/2,-h/2,h/2);
//	glOrtho(-w/2,w/2,-h/2,h/2,-1.0,1.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
//	gluPerspective(45.0,(double)w / (double)h,0.1,200.0);
}
