gcc -Wall -I/usr/include/ -o animation -L/usr/X11R6/lib $1 -lglut -lGL -lGLU -lm -lSOIL 
./animation
